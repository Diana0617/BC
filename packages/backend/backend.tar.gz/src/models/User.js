const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/database');
const bcrypt = require('bcryptjs');

const User = sequelize.define('User', {
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true
  },
  email: {
    type: DataTypes.STRING,
    allowNull: false,
    unique: true,
    validate: {
      isEmail: true
    }
  },
  password: {
    type: DataTypes.STRING,
    allowNull: false,
    validate: {
      len: [6, 255]
    }
  },
  firstName: {
    type: DataTypes.STRING,
    allowNull: false,
    validate: {
      len: [2, 50]
    }
  },
  lastName: {
    type: DataTypes.STRING,
    allowNull: false,
    validate: {
      len: [2, 50]
    }
  },
  phone: {
    type: DataTypes.STRING,
    allowNull: true,
    validate: {
      len: {
        args: [10, 15],
        msg: 'El teléfono debe tener entre 10 y 15 caracteres'
      }
    }
  },
  role: {
    type: DataTypes.ENUM('OWNER', 'BUSINESS', 'SPECIALIST', 'RECEPTIONIST', 'CLIENT', 'RECEPTIONIST_SPECIALIST', 'BUSINESS_SPECIALIST'),
    allowNull: false,
    defaultValue: 'CLIENT'
  },
  status: {
    type: DataTypes.ENUM('ACTIVE', 'INACTIVE', 'SUSPENDED'),
    allowNull: false,
    defaultValue: 'ACTIVE'
  },
  avatar: {
    type: DataTypes.STRING,
    allowNull: true
  },
  businessId: {
    type: DataTypes.UUID,
    allowNull: true,
    references: {
      model: 'businesses',
      key: 'id'
    }
  },
  lastLogin: {
    type: DataTypes.DATE,
    allowNull: true
  },
  emailVerified: {
    type: DataTypes.BOOLEAN,
    defaultValue: false
  },
  emailVerificationToken: {
    type: DataTypes.STRING,
    allowNull: true
  },
  passwordResetToken: {
    type: DataTypes.STRING,
    allowNull: true
  },
  passwordResetExpires: {
    type: DataTypes.DATE,
    allowNull: true
  }
}, {
  tableName: 'users',
  timestamps: true,
  hooks: {
    // Comentado para evitar doble hasheo - el AuthController ya hashea la contraseña
    // beforeCreate: async (user) => {
    //   if (user.password) {
    //     const salt = await bcrypt.genSalt(12);
    //     user.password = await bcrypt.hash(user.password, salt);
    //   }
    // },
    // beforeUpdate: async (user) => {
    //   if (user.changed('password')) {
    //     const salt = await bcrypt.genSalt(12);
    //     user.password = await bcrypt.hash(user.password, salt);
    //   }
    // }
  },
  scopes: {
    active: {
      where: {
        status: 'ACTIVE'
      }
    },
    byBusiness: (businessId) => ({
      where: {
        businessId: businessId
      }
    })
  }
});

// Métodos de instancia
User.prototype.comparePassword = async function(candidatePassword) {
  return await bcrypt.compare(candidatePassword, this.password);
};

User.prototype.toJSON = function() {
  const values = Object.assign({}, this.get());
  delete values.password;
  delete values.emailVerificationToken;
  delete values.passwordResetToken;
  delete values.passwordResetExpires;
  return values;
};

module.exports = User;